import dashscope
from dashscope import MultiModalConversation
from pdf2image import convert_from_path
from pathlib import Path
import io
import base64
import os

# ================= 配置区域 =================
dashscope.api_key = "sk-777ae59d8b3e451db4dd91fe6961dbe5"

# 本地文件路径
pdf_file_path = r"E:\文件\学习\八斗ai\第10周：多模态大模型\Week10-多模态大模型.pdf"

# 使用的模型名称
MODEL_NAME = "qwen2.5-vl-7b-instruct"


# ===========================================

def get_pdf_first_page_base64(file_path):
    """
    读取 PDF 第一页并转换为 Base64
    """
    path_obj = Path(file_path)

    if not path_obj.exists():
        raise FileNotFoundError(f"找不到文件: {file_path}")

    print(f" 正在加载 PDF: {path_obj.name} ...")

    try:
        # 转换第一页，dpi=150 保证文字清晰度
        images = convert_from_path(path_obj, first_page=1, last_page=1, dpi=150)

        if not images:
            raise ValueError("无法转换 PDF 页面")

        img = images[0]

        # 转换为 Base64
        buffered = io.BytesIO()
        img.save(buffered, format="PNG")
        img_str = base64.b64encode(buffered.getvalue()).decode('utf-8')

        return img_str
    except Exception as e:
        print(f" PDF 转换错误: {e}")
        print(" 提示: 请检查是否已安装并配置好 Poppler 环境变量")
        raise e


def call_qwen_2_5_vl(image_base64):
    """
    调用 Qwen2.5-VL-7B-Instruct 进行解析
    """
    prompt = """
    你是一位专业的多模态大模型课程助教。请分析这张 PDF 第一页的图片内容：
    1. 提取标题和副标题。
    2. 总结本页的核心知识点或大纲。
    3. 如果页面上有代码片段或架构图，请简要描述。
    请保持回答结构清晰，使用 Markdown 格式。
    """

    messages = [
        {
            "role": "user",
            "content": [
                {"image": f"data:image/png;base64,{image_base64}"},
                {"text": prompt}
            ]
        }
    ]

    print(f"\n正在调用 {MODEL_NAME} 模型进行解析...\n")

    try:
        response = MultiModalConversation.call(
            model=MODEL_NAME,
            messages=messages,
            stream=True  # 开启流式输出，体验更好
        )

        full_response = ""

        for chunk in response:
            if chunk.status_code == 200:
                # 1. 先获取 choices 列表
                choices = chunk.output.choices
                if choices:
                    # 2. 取出列表中的第一个元素 (索引 0)
                    choice = choices[0]

                    # 3. 获取 message 对象
                    message = choice.message

                    # 4. 获取 content (通常是一个列表 [{'text': '...'}])
                    content = message.content
                    if content:
                        text = content[0].get("text", "")
                        print(text, end="", flush=True)
                        full_response += text
            else:
                print(f"\n请求失败: {chunk.code} - {chunk.message}")

        return full_response

    except Exception as e:
        print(f" 调用模型出错: {e}")
        return None


def main():
    try:
        # 1. 转换图片
        image_base64 = get_pdf_first_page_base64(pdf_file_path)

        # 2. 调用模型
        result = call_qwen_2_5_vl(image_base64)

        if result:
            print(f"\n\n 解析完成！")

    except Exception as e:
        print(f"程序执行中断: {e}")


if __name__ == "__main__":
    main()