import torch
from PIL import Image
from transformers import CLIPProcessor, CLIPModel

# --- 配置路径 ---
# 模型路径
model_path = r"E:\models\AI-ModelScope\chinese-clip-vit-base-patch16"
# 图片路径
image_path = r"E:\文件\学习\八斗ai\第10周：多模态大模型\作业\dog.jpg"

# --- 1. 加载模型 ---
print(f"正在加载模型: {model_path} ...")
try:
    model = CLIPModel.from_pretrained(model_path)
    processor = CLIPProcessor.from_pretrained(model_path)
    print(" 模型加载完成")
except Exception as e:
    print(f"模型加载失败: {e}")
    exit()

# --- 2. 准备分类标签 ---
# 因为使用的是 Chinese-CLIP，这里使用中文标签效果最好
# 我们可以设置一些干扰项来测试 Zero-shot 的能力 尝试具体的品种
candidate_labels = [
    "狗",
    "猫",
    "汽车",
    "飞机",
    "蛋糕",
    "哈士奇",
    "金毛"
]

# --- 3. 加载图片 ---
print(f"正在读取图片: {image_path}")
try:
    image = Image.open(image_path).convert("RGB")
except FileNotFoundError:
    print(f"❌ 找不到图片文件，请检查路径: {image_path}")
    exit()



# --- 4. 推理计算 ---
inputs = processor(
    text=candidate_labels,
    images=image,
    return_tensors="pt",
    padding=True
)

inputs.pop("token_type_ids", None)

with torch.no_grad():
    outputs = model(**inputs)
    # 计算 logits (相似度分数)
    logits_per_image = outputs.logits_per_image
    # 转换为概率 (0-1之间)
    probs = logits_per_image.softmax(dim=1)

# --- 5. 打印结果 ---
print(f"\n--- 分类结果 ---")
# 将结果打包并排序
results = []
for label, prob in zip(candidate_labels, probs[0]):
    results.append((label, prob.item()))

# 按概率从高到低排序
results.sort(key=lambda x: x[1], reverse=True)

for i, (label, prob) in enumerate(results):
    # 打印条形图效果
    bar_len = int(prob * 30)
    bar = "█" * bar_len
    print(f"{i+1}. {label:<8}: {prob:.4f} {bar}")

print(f"\n 最终结论：这张图片是 **{results[0][0]}** (置信度: {results[0][1]:.2%})")